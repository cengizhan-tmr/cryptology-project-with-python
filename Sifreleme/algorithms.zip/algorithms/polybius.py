def polybius_sifreleme():
    pass