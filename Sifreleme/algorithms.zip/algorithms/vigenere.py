def vigenere_sifreleme():
    pass