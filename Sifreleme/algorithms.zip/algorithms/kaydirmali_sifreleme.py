def kaydirmali_sifreleme(text, shift):
    result = ""
    
    # Her karakteri kontrol et
    for char in text:
        # Eğer karakter harfse (alfabetik karakter)
        if char.isalpha():
            # Eğer büyük harfse
            if char.isupper():
                result += chr((ord(char) - 65 + shift) % 26 + 65)
            # Eğer küçük harfse
            else:
                result += chr((ord(char) - 97 + shift) % 26 + 97)
        else:
            # Eğer karakter harf değilse olduğu gibi ekle
            result += char
    
    return result