def yerdegistirme_sifreleme():
    pass