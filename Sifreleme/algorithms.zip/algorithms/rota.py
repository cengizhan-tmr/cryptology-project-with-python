def rota_sifreleme():
    pass