def dogrusal_sifreleme():
    pass