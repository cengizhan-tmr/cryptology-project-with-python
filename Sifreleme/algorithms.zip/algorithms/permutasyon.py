def permutasyon_sifreleme(text, key):
    # Anahtarın uzunluğuna göre her harfi yer değiştirerek şifreler
    result = ""
    # Anahtarın uzunluğuna göre metnin her karakterinin yeni pozisyonunu hesapla
    for i in range(len(text)):
        if text[i].isalpha():  # Sadece harfleri şifrele
            # Anahtarı kullanarak karakterin yeni pozisyonunu hesapla
            new_index = key[i % len(key)]  # Anahtardaki pozisyona göre
            new_char = text[new_index]  # Yeni karakter
            # Karakterin küçük veya büyük olmasına göre düzenle
            if text[i].isupper():
                result += new_char.upper()
            else:
                result += new_char.lower()
        else:
            result += text[i]  # Eğer harf değilse olduğu gibi bırak
    return result